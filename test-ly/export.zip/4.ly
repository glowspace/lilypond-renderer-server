\version "2.22.0"
\include "satb_parts/satb-header.ly"
\include "global.ily"

keyMajor = c
timeSignature = \time 4/4


% --------------  ZAČÁTEK NOT  -------------------

solo = \relative {
	e'2. d8 e | f e4. d8 f4 e8 ~ | e2 r4 d8 e | f8 e4. d8 f r4 |
  r2. a8 e8 ~ | e2 r8 b'4 e,8 ~ | e2. c'8 f,8 ~ | f4. f8 \tuplet 5/4 { f8 e d d e } ~ |
  e2 r | r2
}

soloText = \lyricmode {
	\set stanza = "4."
  Vím, stá -- le kři -- čím, Pa -- ne, vím, den -- ně kři -- čím, Pa -- ne:
  Na kříž s_lás -- kou ry -- zí, i ta má ce -- nu svou.
}

akordy = \chordmode {
	a1:m f a:m f
  a:m a:sus2 a:m d:m e2 e:sus4 e
}

sopran = \relative {
  e'2( d c1) e2( d e1) a2( e ~ e2. f4 e1 f2 a gis1.)
}

alt = \relative {
  c'2( b a1) c2( b c1) c1( a4 c d b c1 a2. d4 e1.)
}

altText = \lyricmode {
  Vím __ vím __ á __
}

tenor = \relative {
  e1 f4 g a b e,1 f4 g a b
  e,1( ~ e e4 g a e f a2. b1.)
}

bas = \relative {
  a,1 a4 b c d a1 a4 b c d
  a1( b c d2 e ~ e1 ~ e2)
}

basText = \lyricmode {
  Vím kři -- čím, Pa -- ne, vím kři -- čím, Pa -- ne.
  á __
}

% --------------  KONEC NOT  -------------------


\include "satb_parts/satb-part.ly"	
