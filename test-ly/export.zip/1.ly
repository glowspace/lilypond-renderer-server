\version "2.22.0"
\include "satb_parts/satb-header.ly"
\include "global.ily"

keyMajor = c
timeSignature = \time 4/4


% --------------  ZAČÁTEK NOT  -------------------

solo = \relative {
	e'2. d8 e | f e4. d8 f4 e8 ~ | e2 r4 d8 e | f4 e d8 f r4 |
  r2 r8 a4 e8 ~ | e2 r8 b'4 e,8 ~ | e2 r8 c'4 f,8 ~ | f2 \tuplet 5/4 { f8 e d d e } ~ |
  e2 r | r1
}

soloText = \lyricmode {
	\set stanza = "1."
  Mám v_o -- čích bo -- lest, Pa -- ne, mám ru -- ce prázd -- né, Pa -- ne.
  Tvůj kříž tmou stál, můj hřích, ten ho pod -- pí -- ral.
}

akordy = \chordmode {
	a1:m f a:m f
  a:m a:sus2 a:m d:m e2 e:sus4 e1
}

% --------------  KONEC NOT  -------------------


\include "satb_parts/satb-part.ly"	
