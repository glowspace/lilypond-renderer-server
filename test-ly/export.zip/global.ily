twoVoicesPerStaff = ##t
globalTransposeRelativeC = c

% sjednoti pomlky pro vicehlasy
\layout { \context { \Staff \consists "Merge_rests_engraver" } }

% skryje cisla taktu
\layout { \context { \Score \remove "Bar_number_engraver" } }

\layout {
    \context {
      \Voice
      % Automatic note splitting http://lilypond.org/doc/v2.22/Documentation/notation/displaying-rhythms#automatic-note-splitting
      % this was edited to be idempotent as it may be included multiple times
      \remove "Note_heads_engraver"
      \remove "Completion_heads_engraver"
      \consists "Completion_heads_engraver"
      \remove "Rest_engraver"
      \remove "Completion_rest_engraver"
      \consists "Completion_rest_engraver"
    }
}

\paper { print-page-number = ##f }
font = #"amiri"
chordFont = #"amiri"
fontSize = 2.5
chordFontSize = 1.5

\layout {
    \context {
      \Lyrics {
        \override LyricText #'font-name = \font
        \override StanzaNumber #'font-name = \font
        \override LyricText #'font-size = \fontSize	
        \override StanzaNumber #'font-size = \fontSize
      }
    }
    \context {
      \ChordNames
      \override ChordName #'font-name = \chordFont
      \override ChordName #'font-size = \chordFontSize
    }
}

#(ly:font-config-add-font "fonts/amiri.otf")

\paper {
  #(set-paper-size "a4")
  indent = 0
  top-margin = 1
  system-system-spacing.padding = 2
}


