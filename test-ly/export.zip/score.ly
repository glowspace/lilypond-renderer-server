\version "2.22.0"

\include "satb_parts/satb-header.ly"
globalRender = ##t


% --------------  ZAČÁTEK NOT  -------------------


partTranspose = ##f
\include "1.ly"


Time = { #(if Time Time) \bar "||" }


Time = { #(if Time Time) \break }

partTranspose = ##f
\include "2.ly"

partTranspose = ##f
\include "R.ly"


Time = { #(if Time Time) \bar "||" }


Time = { #(if Time Time) \break }

partTranspose = ##f
\include "3.ly"


Time = { #(if Time Time) \bar "||" }


Time = { #(if Time Time) \break }

partTranspose = ##f
\include "4.ly"

partTranspose = ##f
\include "R.ly"


Time = { #(if Time Time) \bar "|." }


% --------------  KONEC NOT  -------------------


\include "satb_parts/satb-footer.ly"	
