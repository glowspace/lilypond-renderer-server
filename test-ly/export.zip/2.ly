\version "2.22.0"
\include "satb_parts/satb-header.ly"
\include "global.ily"

keyMajor = c
timeSignature = \time 4/4


% --------------  ZAČÁTEK NOT  -------------------

solo = \relative {
	e'2. d8 e | f e4. d8 f4 e8 ~ | e2 r4 d8 e | f4 e d8 f r4 |
  r2 r8 a4 e8 ~ | e2 r8 b'4 e,8 ~ | e2 r4 c'8  f,8 ~ | f2 \tuplet 5/4 { f8 e d d e } ~ |
  e2 r | r
}

soloText = \lyricmode {
	\set stanza = "2."
  Mám v_srd -- ci tou -- hu, Pa -- ne, mám sil -- nou tou -- hu, Pa -- ne.
  Můj hřích, můj pláč při -- bít tam, kdes u -- mí -- ral.
}

akordy = \chordmode {
	a1:m f a:m f
  a:m a:sus2 a:m d:m e2 e:sus4 e
}

sopran = \relative {
  e'2( d c1) e2( d e1) a2( e ~ e2. f4 e1 f2 a gis1.)
}

alt = \relative {
  c'2( b a1) c2( b c1) c1( a4 c d b c1 a2. d4 e1.)
}

altText = \lyricmode {
  Mám __ mám __ á __
}

tenor = \relative {
  e1 f4 g a b e,1 f4 g a b
  e,1( ~ e e4 g a e f a2. b1.)
}

bas = \relative {
  a,1 a4 b c d a1 a4 b c d
  a1( b c d2 e ~ e1 ~ e2)
}

basText = \lyricmode {
  Mám tou -- hu, Pa -- ne, mám tou -- hu, Pa -- ne.
  á __
}

% --------------  KONEC NOT  -------------------


\include "satb_parts/satb-part.ly"	
