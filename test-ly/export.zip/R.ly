\version "2.22.0"
\include "satb_parts/satb-header.ly"
\include "global.ily"

keyMajor = c
timeSignature = \time 4/4


% --------------  ZAČÁTEK NOT  -------------------

solo = \relative {
  \partial 2 { r8 b'4 c8 ~ } 

  | c4 r4. a8 b c ~ | c2 r8 d4 b8 ~ 
  | b4 r \tuplet 5/4 { b8 a g g b ~ } 
  | b4 r2 b8 a ~ | a2 a8 g f16 e8. 
	| f4 r2 g8 e ~ | e2  \tuplet 5/4 { e8 d c d e } ~ 
	| e4 r r8 b'4 c8 ~ | c4 r \tuplet 3/2 { c d c } 
	| r2 c8 d4 c8( ~ | c2 ~ c8 b4 a8 ~ 
	| a2) r8 g4 a8 ~ | a4 r \tuplet 5/4 { a8 g f e f ~ } 
	| f2 r4 g8 e ~ e2 \tuplet 5/4 { e8 d c d e ~ } e4 r2.  
}

soloText = \lyricmode {
	\set stanza = "R:"
  Ten den svět se smál, ten den svět to ne -- chá -- pal
 a já, já byl Ji -- dá -- šem, co svůj ži -- vot za -- pro -- dal.
  Ten den spal jsem snad to -- lik -- rát.
  Ten den já byl Ji -- dá -- šem, co svůj ži -- vot za -- pro -- dal.
}

akordy = \chordmode {
	s2 a1:m f g c
  f d:m e a:m s
  a:sus2 a:m d:m
  f d:m e a:m
}

sopran = \relative {
  \partial 2 r2 e'4. e8 ~ e2 | e4 e8 e ~ e2 | d4. d8 ~ d2 | d8 d4 d8 ~ d4 r | r c2 c4  |
  c8 c4 c8 ~ c4  c8 b( ~ b1 c2) r | a'2( e ~ e2. f4 e1 f2) r8 f4 f8 ~ f4 r f8 f f e |
  f4 r2 g8 e ~ | e1 ~ | e2 r
}

alt = \relative {
  \partial 2 r2 c'4. c8 ~ c2 | c4 c8 c ~ c2 | b4. b8 ~ b2 | b8 b4 b8 ~ b4 r | r a2 a4  |
  a8 a4 a8 ~ a4  a8 gis( ~ gis1 a2) r | a2( ~ a b1 c1 d2) r8 d4 c8 ~ c4 r c8 c d b |
  a4 r2 a8 gis( ~ | gis1 | a2) r
}

altText = \lyricmode {
  Ten den svět se smál, ten den ne -- chá -- pal. Já byl Ji -- dá -- šem,
  co svůj __ á __ ten den já byl Ji -- dá -- šem, co svůj __
}

tenor = \relative {
  \partial 2 r2 a4. a8 ~ a2 | a4 a8 a ~ a2 
 | g4. g8 ~ g2 | g8 g4 g8 ~ g4 r | r f2 f4  |
  f8 f4 f8 ~ f4  f8 e ~ e2 \tuplet 5/4 { e8 d c d e } ~ e4 r r8 b'4 c8 ~ | c4 r \tuplet 3/2 { c d c } r2 
| \tuplet 3/2 { c4 d c( ~ } c2 ~ c8 b4 a8 ~ 
| a2) r8 g4 a8 ~ |
  a4 r a8 g f e | f4 r2 g8 e ~ | e2 \tuplet 5/4 { e8 d c d e } e4 r2.   
}

bas = \relative {
 \partial 2 r2 c4. c8 ~ c2 | f4 f8 f ~ f2 
 | b,4. b8 ~ b2 | e8 e4 e8 ~ e4 r | r a,2 a4  |
  d8 d4 d8 ~ d4  f8 e ~ e2 \tuplet 5/4 { e8 d c d e } ~ |
  e4 r r8 b4 c8 ~ | c4 r \tuplet 3/2 { c d c } r2 
| \tuplet 3/2 { c4 d c( ~ } c1 ~ c2) r8 g'4 a8 ~ |
  a4 r a8 g f e | f4 r2 g8 e ~ | e2 \tuplet 5/4 { e8 d c d e } e4 r2.   
}

basText = \lyricmode {
  Ten den svět se smál, ten den ne -- chá -- pal. Já byl Ji -- dá -- šem,
  co svůj ži -- vot za -- pro -- dal. Ten den spal jsem snad to -- li -- krát. __
  Ten den já byl Ji -- dá -- šem, co svůj ži -- vot za -- pro -- dal.
}

% --------------  KONEC NOT  -------------------


\include "satb_parts/satb-part.ly"	
